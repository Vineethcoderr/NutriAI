# NutriAi

An AI-powered nutrition assistant that helps users make healthy food choices based on their goals and preferences.
